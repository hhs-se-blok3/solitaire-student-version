package nl.quintor.solitaire.game.moves.ex;

public class NotYetImplementedException extends MoveException {
    public NotYetImplementedException(String message) {
        super(message);
    }
}
